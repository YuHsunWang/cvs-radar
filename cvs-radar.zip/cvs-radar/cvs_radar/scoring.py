"""公正分數聚合 + 評價共識歸納(PRD F5 / F6 / §8)。

決議 #1:作者自評分與推文合併成單一評分。
決議 #3:author_weight = 0.5(作者佔 50%、推文佔 50%)。
"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import defaultdict
from statistics import mean

from .config import CONSENSUS, CONFIDENCE_BANDS, SCORING
from .config import BRANDS
from .models import Contributor, Post, ProductReport
from .preference import AccountProfile


# ── 商品識別(PRD F5.6)──────────────────────────────────────
def normalize_product(brand: str, name: str) -> str:
    """去品牌前綴、空白、全半形差異,作為同商品分組鍵。"""
    s = unicodedata.normalize("NFKC", name).lower().strip()
    keywords = [k.lower() for k in BRANDS.get(brand, [])] + [brand.lower()]
    for kw in sorted(keywords, key=len, reverse=True):
        s = s.replace(kw, " ")
    s = re.sub(r"\s+", "", s)
    return s


def group_products(posts: list[Post]) -> dict[tuple[str, str], list[Post]]:
    groups: dict[tuple[str, str], list[Post]] = defaultdict(list)
    for p in posts:
        groups[(p.brand, normalize_product(p.brand, p.product_name))].append(p)
    return dict(groups)


# ── 聚合工具 ────────────────────────────────────────────────
def _weighted_mean(pairs: list[tuple[float, float]]) -> float:
    sw = sum(w for _, w in pairs)
    return sum(v * w for v, w in pairs) / sw if sw else 0.0


def _weighted_std(pairs: list[tuple[float, float]], mu: float) -> float:
    sw = sum(w for _, w in pairs)
    if sw <= 0:
        return 0.0
    var = sum(w * (v - mu) ** 2 for v, w in pairs) / sw
    return math.sqrt(max(0.0, var))


def _n_eff(weights: list[float]) -> float:
    s1 = sum(weights)
    s2 = sum(w * w for w in weights)
    return (s1 * s1 / s2) if s2 > 0 else 0.0


def _confidence(n_eff: float) -> str:
    for thr, label in CONFIDENCE_BANDS:
        if n_eff < thr:
            return label
    return "高"


def _classify(mu: float, std: float, n_eff: float) -> str:
    if n_eff < CONSENSUS["n_eff_min"]:
        return "資料不足"
    if std >= CONSENSUS["high_std"]:
        return "評價兩極"
    if mu >= CONSENSUS["high_mean"] and std <= CONSENSUS["low_std"]:
        return "一致好評"
    if mu <= CONSENSUS["low_mean"] and std <= CONSENSUS["low_std"]:
        return "一致負評"
    return "褒貶不一"


# ── 主流程:單一商品聚合 ─────────────────────────────────────
def score_product(
    posts: list[Post],
    profiles: dict[str, AccountProfile],
) -> ProductReport:
    aw = SCORING["author_weight"]
    mu0, C = SCORING["prior_mean"], SCORING["prior_strength"]
    authors = {p.author for p in posts}

    # 1) 作者自評分元件(0–1):取所有有評分的文章平均
    author_scores01 = [p.author_score / 100.0 for p in posts if p.author_score is not None]
    author_component = mean(author_scores01) if author_scores01 else None

    # 2) 留言元件:每人每商品折一票、排除作者自推、信度加權、貝氏收斂
    per_user: dict[str, list[float]] = defaultdict(list)
    for p in posts:
        for c in p.comments:
            if c.sentiment is None:
                continue
            if SCORING["exclude_self_push"] and c.user in authors:
                continue
            per_user[c.user].append((c.sentiment + 1) / 2.0)  # → [0,1]

    pairs: list[tuple[float, float]] = []          # (score01, weight)
    contributors: list[Contributor] = []
    for user, scores in per_user.items():
        stance = mean(scores) if SCORING["per_user_cap"] else scores  # 折一票
        cred = profiles[user].credibility if user in profiles else 1.0
        if SCORING["per_user_cap"]:
            pairs.append((stance, cred))
            contributors.append(Contributor(user, "commenter", round(stance, 3), round(cred, 3)))
        else:
            for s in scores:
                pairs.append((s, cred))

    comment_weights = [w for _, w in pairs]
    if pairs:
        # 貝氏收斂:加入 C 個先驗虛擬票拉向 μ0
        num = mu0 * C + sum(v * w for v, w in pairs)
        den = C + sum(comment_weights)
        comment_component = num / den
    else:
        comment_component = None

    # 3) 合併(50/50):缺一端時用另一端
    if author_component is not None and comment_component is not None:
        fair01 = aw * author_component + (1 - aw) * comment_component
    elif author_component is not None:
        fair01 = author_component
    elif comment_component is not None:
        fair01 = comment_component
    else:
        fair01 = None

    # 作者也列為貢獻者(可解釋)
    for p in posts:
        if p.author_score is not None:
            contributors.append(
                Contributor(p.author, "author", round(p.author_score / 100.0, 3), 1.0)
            )

    # 4) 共識:對「所有意見」(作者自評 + 每人留言立場)算加權均值/離散
    opinion_pairs = [(s, 1.0) for s in author_scores01] + pairs
    if opinion_pairs:
        mu = _weighted_mean(opinion_pairs)
        std = _weighted_std(opinion_pairs, mu)
        n_eff = _n_eff([w for _, w in opinion_pairs])
    else:
        mu, std, n_eff = 0.0, 0.0, 0.0

    consensus = _classify(mu, std, n_eff)
    confidence = _confidence(n_eff)

    # 5) 代表性正負評(供「評價兩極」展示)
    rep_pos, rep_neg = _rep_comments(posts, authors)

    return ProductReport(
        brand=posts[0].brand,
        product_name=posts[0].product_name,
        fair_score=round(fair01 * 100, 1) if fair01 is not None else None,
        consensus=consensus,
        confidence=confidence,
        n_eff=round(n_eff, 2),
        score_std=round(std, 3),
        n_posts=len(posts),
        n_comments=sum(len(p.comments) for p in posts),
        contributors=sorted(contributors, key=lambda c: -c.weight),
        rep_positive=rep_pos,
        rep_negative=rep_neg,
    )


def _rep_comments(posts: list[Post], authors: set[str], k: int = 3):
    pos, neg = [], []
    for p in posts:
        for c in p.comments:
            if c.sentiment is None or not c.text.strip():
                continue
            (pos if c.sentiment > 0.2 else neg if c.sentiment < -0.2 else []).append(
                (c.sentiment, c.text.strip())
            )
    pos.sort(key=lambda x: -x[0])
    neg.sort(key=lambda x: x[0])
    return [t for _, t in pos[:k]], [t for _, t in neg[:k]]


def score_all(posts: list[Post], profiles: dict[str, AccountProfile]) -> list[ProductReport]:
    reports = [score_product(g, profiles) for g in group_products(posts).values()]
    reports.sort(key=lambda r: (r.fair_score is None, -(r.fair_score or 0)))
    return reports
