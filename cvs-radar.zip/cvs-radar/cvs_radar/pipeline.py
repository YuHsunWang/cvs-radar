"""串接整條分析主線(PRD §5)。"""
from __future__ import annotations

from .models import Post, ProductReport
from .preference import AccountProfile, build_profiles
from .scoring import score_all
from .sentiment import analyze_post_comments


def run_pipeline(posts: list[Post]) -> tuple[list[ProductReport], dict[str, AccountProfile]]:
    """輸入已解析的 Post 清單 → 輸出商品報表 + 帳號輪廓。"""
    # 1) 情感分析(每則留言)
    for p in posts:
        analyze_post_comments(p.comments)
    # 2) 帳號偏好輪廓 + 可疑分(需所有貼文一起算)
    profiles = build_profiles(posts)
    # 3) 商品聚合 + 共識
    reports = score_all(posts, profiles)
    return reports, profiles
