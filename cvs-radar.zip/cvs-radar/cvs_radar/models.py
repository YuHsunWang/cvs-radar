"""資料模型(對應 PRD §9)。"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Comment:
    """一則推文(留言)。"""
    tag: str                       # 推 / 噓 / →
    user: str
    text: str
    posted_at: Optional[datetime] = None
    sentiment: Optional[float] = None  # 情感分 ∈ [-1, 1],由 sentiment 模組填入


@dataclass
class Post:
    """一篇 [商品] 文。"""
    url: str
    title: str
    author: str
    brand: str
    product_name: str
    price: Optional[str] = None
    author_score: Optional[float] = None  # 作者自評分(0–100)
    review_text: str = ""
    posted_at: Optional[datetime] = None
    is_reply: bool = False
    push_count: Optional[int] = None
    comments: list[Comment] = field(default_factory=list)
    source: str = "PTT"


@dataclass
class Contributor:
    """對某商品分數有貢獻的單一來源(作者或留言者),供可解釋輸出。"""
    user: str
    role: str          # author / commenter
    score01: float     # 正規化情感分 ∈ [0, 1]
    weight: float      # 信度權重


@dataclass
class ProductReport:
    """單一商品的彙整結果。"""
    brand: str
    product_name: str
    fair_score: Optional[float]    # 公正分數 0–100(無資料為 None)
    consensus: str                 # 一致好評 / 一致負評 / 評價兩極 / 褒貶不一 / 資料不足
    confidence: str                # 低 / 中 / 高
    n_eff: float
    score_std: float
    n_posts: int
    n_comments: int
    contributors: list[Contributor] = field(default_factory=list)
    rep_positive: list[str] = field(default_factory=list)
    rep_negative: list[str] = field(default_factory=list)
