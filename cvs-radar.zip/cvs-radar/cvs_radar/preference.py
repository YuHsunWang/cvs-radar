"""帳號偏好輪廓 + 可疑操作訊號(PRD F4 / §8)。

重點(對應使用者決議 #2):可疑分**僅作 F5 內部降權**,不對外公開個別標籤。
低於活動量門檻者不評分,避免低樣本誤判。可疑分可解釋(列出各特徵貢獻)。
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from statistics import mean

from .config import SUSPICION
from .models import Post


@dataclass
class AccountProfile:
    user: str
    brand_stats: dict[str, dict] = field(default_factory=dict)  # brand -> {count, avg_sentiment, scores[]}
    total_comments: int = 0
    lean_brand: str | None = None
    suspicion: float = 0.0
    suspicion_features: dict[str, float] = field(default_factory=dict)

    @property
    def credibility(self) -> float:
        """信度權重 = max(下限, 1 - 可疑分)。"""
        return max(SUSPICION["weight_floor"], 1.0 - self.suspicion)


def build_profiles(posts: list[Post]) -> dict[str, AccountProfile]:
    """掃描所有貼文的留言,建立每個帳號的品牌偏好輪廓並計算可疑分。"""
    acc: dict[str, AccountProfile] = {}
    raw: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))

    for post in posts:
        for c in post.comments:
            if c.sentiment is None:
                continue
            raw[c.user][post.brand].append(c.sentiment)

    for user, brands in raw.items():
        prof = AccountProfile(user=user)
        total = 0
        for brand, sents in brands.items():
            prof.brand_stats[brand] = {
                "count": len(sents),
                "avg_sentiment": round(mean(sents), 3),
                "scores": sents,
            }
            total += len(sents)
        prof.total_comments = total
        prof.lean_brand = _lean_brand(prof.brand_stats)
        prof.suspicion, prof.suspicion_features = _suspicion(prof)
        acc[user] = prof
    return acc


def _lean_brand(brand_stats: dict[str, dict]) -> str | None:
    """以平均情感最高的品牌為偏好(需有正向傾向)。"""
    best, best_avg = None, -2.0
    for brand, st in brand_stats.items():
        if st["avg_sentiment"] > best_avg:
            best, best_avg = brand, st["avg_sentiment"]
    return best if best_avg > 0 else None


def _suspicion(prof: AccountProfile) -> tuple[float, dict[str, float]]:
    """多弱訊號加權(截到 [0,1])。低於活動量門檻 → 不評分(回 0)。"""
    feats: dict[str, float] = {}
    if prof.total_comments < SUSPICION["min_activity"]:
        return 0.0, {"_below_activity_gate": 1.0}

    fw = SUSPICION["feature_weights"]
    stats = prof.brand_stats

    # 1) 一面倒:對最愛品牌全正、對其他品牌全負
    fav = prof.lean_brand
    one_sided = 0.0
    if fav and len(stats) >= 2:
        fav_avg = stats[fav]["avg_sentiment"]
        others = [st["avg_sentiment"] for b, st in stats.items() if b != fav]
        if fav_avg > 0.5 and others and max(others) < -0.2:
            one_sided = 1.0
        elif fav_avg > 0.3 and others and mean(others) < 0:
            one_sided = 0.6
    feats["one_sided"] = one_sided

    # 2) 單一品牌:只在一個品牌活動(且量不算少)
    single = 1.0 if (len(stats) == 1 and prof.total_comments >= SUSPICION["min_activity"]) else 0.0
    feats["single_brand"] = single

    # 3) 極端性:情感分長期貼極值
    all_scores = [s for st in stats.values() for s in st["scores"]]
    extreme_ratio = sum(1 for s in all_scores if abs(s) >= 0.8) / len(all_scores)
    feats["extremity"] = extreme_ratio if extreme_ratio > 0.7 else 0.0

    score = sum(feats[k] * fw[k] for k in fw)
    return min(1.0, score), feats
