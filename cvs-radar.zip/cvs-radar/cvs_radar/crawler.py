"""PTT 爬蟲(PRD F1)。

禮貌爬取:自訂 UA、請求間隔、逾時、指數退避重試;增量快取避免重複。
注意:沙箱環境對外網路擋掉 ptt.cc,本檔需於有網路的機器執行。
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Iterator, Optional

import requests

from .config import CRAWL
from .models import Post
from .parser import parse_article, parse_listing


class PttCrawler:
    def __init__(self, cache_path: str | Path = "seen_urls.json"):
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": CRAWL["user_agent"]})
        self.s.cookies.set("over18", "1", domain=".ptt.cc")  # 保險(CVS 非 18+)
        self.cache_path = Path(cache_path)
        self.seen: set[str] = set()
        if self.cache_path.exists():
            self.seen = set(json.loads(self.cache_path.read_text()))

    # ── 低階請求(重試 + 退避)──
    def _get(self, url: str) -> Optional[str]:
        for attempt in range(CRAWL["retries"]):
            try:
                r = self.s.get(url, timeout=CRAWL["timeout_sec"])
                if r.status_code == 200:
                    return r.text
            except requests.RequestException:
                pass
            time.sleep((2 ** attempt) * CRAWL["request_delay_sec"])
        return None

    # ── 列表頁逐頁往回 ──
    def iter_listing(self, max_pages: int | None = None) -> Iterator[dict]:
        max_pages = max_pages or CRAWL["max_pages"]
        url = f"{CRAWL['base_url']}/bbs/{CRAWL['board']}/index.html"
        for _ in range(max_pages):
            html = self._get(url)
            if not html:
                break
            items, prev = parse_listing(html, CRAWL["base_url"])
            yield from items
            time.sleep(CRAWL["request_delay_sec"])
            if not prev:
                break
            url = prev

    # ── 完整爬取:回傳 [商品] 文的 Post ──
    def crawl(self, max_pages: int | None = None, only_product: bool = True,
              skip_seen: bool = True) -> list[Post]:
        posts: list[Post] = []
        for item in self.iter_listing(max_pages):
            if only_product and "[商品]" not in item["title"]:
                continue
            if skip_seen and item["url"] in self.seen:
                continue
            html = self._get(item["url"])
            self.seen.add(item["url"])
            time.sleep(CRAWL["request_delay_sec"])
            if not html:
                continue
            post = parse_article(html, item["url"])
            if post:
                posts.append(post)
        self._save_cache()
        return posts

    def _save_cache(self):
        self.cache_path.write_text(json.dumps(sorted(self.seen), ensure_ascii=False))
