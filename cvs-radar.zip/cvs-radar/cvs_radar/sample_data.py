"""離線樣本(無網路時測試分析主線)。

post1 完全取自真實抓到的 PTT 文(阜杭豆漿饅頭夾豬排蛋,自評 85,12 則推文)。
另外加幾筆合成資料,用來示範:多篇文章評價兩極、以及疑似操作帳號的降權效果。
"""
from __future__ import annotations

from .models import Comment, Post


def _c(tag, user, text):
    return Comment(tag=tag, user=user, text=text)


# ── 真實資料:711 阜杭豆漿饅頭夾豬排蛋 ─────────────────────────
post_real = Post(
    url="https://www.ptt.cc/bbs/CVS/M.1779373616.A.69E.html",
    title="[商品] 711 阜杭豆漿饅頭夾豬排蛋",
    author="kevinlee2001", brand="7-11",
    product_name="阜杭豆漿饅頭夾豬排蛋", price="69", author_score=85,
    review_text="肉吃起來跟早餐店豬排一模一樣,裡面有花生醬蠻意外,口味很棒,乞丐時光很推",
    comments=[
        _c("推", "YingWenTsai", "好吃"),
        _c("→", "q210216", "小七是i珍食...!="),
        _c("推", "daisy526e", "有花生醬很加分"),
        _c("推", "cashko", "不錯吃"),
        _c("推", "yjlee0829", "這款好吃 但最近似乎比較少看到"),
        _c("推", "scores", "剛買，好吃。回購率高"),
        _c("→", "steven183", "喜歡"),
        _c("推", "scores", "我覺得這樣夾心，比之前更貴的掛包好吃多了"),
        _c("→", "scores", "沒辦法把三層滷到軟爛吃起來超硬。還不如這個豬排好吃"),
        _c("推", "firetim", "其實甜的我有點錯愕，這個我不愛甜的QQ"),
        _c("推", "rainhyuk", "這個很好吃！我超喜歡！"),
        _c("推", "YL9212", "比想像中好吃"),
        _c("→", "c48074", "好吃耶 竟然沒賣完"),
    ],
)

# ── 合成:全家 濃厚鮮乳布丁(兩篇、評價兩極)──────────────────
post_pudding_a = Post(
    url="https://example/pudding_a", title="[商品] 全家 濃厚鮮乳布丁",
    author="milklover", brand="全家", product_name="濃厚鮮乳布丁",
    price="45", author_score=90, review_text="奶味很濃,非常好吃",
    comments=[
        _c("推", "aaa111", "超濃郁 好喝"),
        _c("推", "bbb222", "很喜歡這款"),
        _c("噓", "ccc333", "太甜了 我覺得很普"),
        _c("推", "ddd444", "不錯"),
    ],
)
post_pudding_b = Post(
    url="https://example/pudding_b", title="[商品] 全家 濃厚鮮乳布丁",
    author="critic_eat", brand="全家", product_name="濃厚鮮乳布丁",
    price="45", author_score=35, review_text="死甜 香精味重 不推",
    comments=[
        _c("噓", "eee555", "難吃 死甜"),
        _c("噓", "fff666", "香精味好重 雷"),
        _c("推", "ggg777", "還好吧 我覺得不錯"),
    ],
)

# ── 合成:疑似操作帳號(永遠挺 7-11、貶全家)────────────────────
shill = "promo_acct"
post_shill_711 = Post(
    url="https://example/s711", title="[商品] 7-11 招牌大亨堡",
    author="someone", brand="7-11", product_name="招牌大亨堡",
    price="40", author_score=80, review_text="經典",
    comments=[
        _c("推", shill, "超好吃 必買 大推"),
        _c("推", "normaluser", "還行"),
        _c("推", shill, "7-11 最強 回購"),
        _c("推", shill, "這款神 大推 超讚"),
    ],
)
post_shill_fami = Post(
    url="https://example/sfami", title="[商品] 全家 招牌熱狗堡",
    author="someone2", brand="全家", product_name="招牌熱狗堡",
    price="40", author_score=70, review_text="普通",
    comments=[
        _c("噓", shill, "難吃 雷 別買"),
        _c("推", "normaluser2", "我覺得不錯吃"),
        _c("噓", shill, "全家就是不行 難吃"),
        _c("噓", shill, "別碰 超雷"),
    ],
)


def load_sample() -> list[Post]:
    return [post_real, post_pudding_a, post_pudding_b, post_shill_711, post_shill_fami]
