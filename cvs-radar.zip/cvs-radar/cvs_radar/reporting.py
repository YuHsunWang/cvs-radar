"""報表輸出(PRD F7)。

對外輸出**去識別化**:不揭露個別帳號明細(對應決議 #2)。
維運模式 (internal=True) 才顯示貢獻者與可疑分,供人工覆核。
"""
from __future__ import annotations

import json

from .models import ProductReport
from .preference import AccountProfile

_BAR = {"一致好評": "🟢", "一致負評": "🔴", "評價兩極": "🟡",
        "褒貶不一": "🟠", "資料不足": "⚪"}


def render_text(reports: list[ProductReport], internal: bool = False) -> str:
    out = ["超商食物評價雷達 — 商品彙整\n" + "=" * 44]
    for r in reports:
        score = f"{r.fair_score:.1f}" if r.fair_score is not None else "—"
        out.append(
            f"\n{_BAR.get(r.consensus, '·')} [{r.brand}] {r.product_name}\n"
            f"   公正分數 {score}/100　|　{r.consensus}　|　信心度 {r.confidence}\n"
            f"   文章 {r.n_posts} 篇、留言 {r.n_comments} 則"
            f"(有效樣本 {r.n_eff}、離散 {r.score_std})"
        )
        if r.consensus == "評價兩極":
            if r.rep_positive:
                out.append("   ＋ " + "／".join(r.rep_positive[:2]))
            if r.rep_negative:
                out.append("   － " + "／".join(r.rep_negative[:2]))
        if internal and r.contributors:
            who = ", ".join(f"{c.user}({c.role[:4]}:{c.score01},w={c.weight})"
                            for c in r.contributors[:8])
            out.append("   〔內部〕貢獻者:" + who)
    return "\n".join(out)


def render_json(reports: list[ProductReport], internal: bool = False) -> str:
    data = []
    for r in reports:
        d = {
            "brand": r.brand, "product_name": r.product_name,
            "fair_score": r.fair_score, "consensus": r.consensus,
            "confidence": r.confidence, "n_eff": r.n_eff, "score_std": r.score_std,
            "n_posts": r.n_posts, "n_comments": r.n_comments,
            "rep_positive": r.rep_positive, "rep_negative": r.rep_negative,
        }
        if internal:
            d["contributors"] = [vars(c) for c in r.contributors]
        data.append(d)
    return json.dumps(data, ensure_ascii=False, indent=2)


def render_suspicion(profiles: dict[str, AccountProfile], top: int = 10) -> str:
    """維運用:可疑分排行(僅供內部人工覆核,不對外)。"""
    ranked = sorted(profiles.values(), key=lambda p: -p.suspicion)
    out = ["〔內部〕可疑訊號排行(僅供覆核,非指控)\n" + "-" * 40]
    for p in ranked[:top]:
        if p.suspicion <= 0:
            continue
        feats = ", ".join(f"{k}={v}" for k, v in p.suspicion_features.items() if v)
        out.append(f"{p.user:<16} 可疑={p.suspicion:.2f} 偏好={p.lean_brand} "
                   f"留言={p.total_comments} [{feats}]")
    return "\n".join(out) if len(out) > 1 else "（無達標可疑帳號）"
