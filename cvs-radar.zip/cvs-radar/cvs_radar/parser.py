"""PTT HTML 解析(PRD F2 / §7)。

對應前面實際抓到的結構:
- 列表頁:div.r-ent > div.title a / div.nrec / div.meta(author,date)
- 文章頁:div.article-metaline(作者/標題/時間)、#main-content 內文、div.push(推文)
解析失敗以空值表示而不報錯。
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Optional

from bs4 import BeautifulSoup

from .config import BRANDS, BRAND_OTHER
from .models import Comment, Post

PTT_DATE_RE = re.compile(r"\w{3}\s+\w{3}\s+\d+\s+\d+:\d+:\d+\s+\d{4}")
FIELD_RE = {
    "name_price": re.compile(r"【商品名稱/價格】[：:]\s*(.+)"),
    "brand": re.compile(r"【便利商店/廠商名稱】[：:]\s*(.+)"),
    "score": re.compile(r"【評分】[：:]\s*([^\n【]+)"),
}


def detect_brand(text: str) -> str:
    low = text.lower()
    for brand, kws in BRANDS.items():
        if any(kw.lower() in low for kw in kws):
            return brand
    return BRAND_OTHER


def parse_author_score(raw: str) -> Optional[float]:
    """解析【評分】:支援 85 / 8/10 / ★ 星數 / 無 等(PRD §7)。"""
    if not raw:
        return None
    raw = raw.strip()
    m = re.search(r"(\d+(?:\.\d+)?)\s*/\s*(\d+)", raw)   # x/y
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        return round(a / b * 100, 1) if b else None
    stars = raw.count("★") + raw.count("⭐")
    if stars:
        return round(stars / 5 * 100, 1)
    m = re.search(r"(\d+(?:\.\d+)?)", raw)               # 純數字
    if m:
        v = float(m.group(1))
        return v if v <= 100 else None
    return None


def _ptt_time(s: str) -> Optional[datetime]:
    m = PTT_DATE_RE.search(s or "")
    if not m:
        return None
    try:
        return datetime.strptime(m.group(0), "%a %b %d %H:%M:%S %Y")
    except ValueError:
        return None


def parse_listing(html: str, base_url: str) -> tuple[list[dict], Optional[str]]:
    """回傳 (文章清單, 上一頁URL)。每筆: {url, title, author, push}。"""
    soup = BeautifulSoup(html, "html.parser")
    items = []
    for ent in soup.select("div.r-ent"):
        a = ent.select_one("div.title a")
        if not a:  # 刪除文無連結 → 跳過
            continue
        nrec = ent.select_one("div.nrec")
        items.append({
            "url": base_url + a["href"],
            "title": a.get_text(strip=True),
            "author": (ent.select_one("div.meta .author") or _Empty()).get_text(strip=True),
            "push": (nrec.get_text(strip=True) if nrec else ""),
        })
    prev = None
    for btn in soup.select("div.btn-group-paging a"):
        if "上頁" in btn.get_text():
            prev = base_url + btn["href"]
    return items, prev


def parse_article(html: str, url: str) -> Optional[Post]:
    """解析單篇文章 → Post(僅 [商品] 文回傳完整欄位)。"""
    soup = BeautifulSoup(html, "html.parser")
    main = soup.select_one("#main-content")
    if not main:
        return None

    meta = {m.select_one(".article-meta-tag").get_text(strip=True):
            m.select_one(".article-meta-value").get_text(strip=True)
            for m in soup.select("div.article-metaline")
            if m.select_one(".article-meta-tag")}
    author = re.sub(r"\s*\(.*\)$", "", meta.get("作者", "")).strip()
    title = meta.get("標題", "")
    posted = _ptt_time(meta.get("時間", ""))

    # 內文:#main-content 去掉 meta 與推文後的文字
    for tag in main.select("div.article-metaline, div.article-metaline-right, div.push, span.f2"):
        tag.extract()
    body = main.get_text("\n")

    np_m = FIELD_RE["name_price"].search(body)
    name, price = title, None
    if np_m:
        np = np_m.group(1).strip()
        if "/" in np:
            name, price = np.rsplit("/", 1)
            name, price = name.strip(), price.strip()
        else:
            name = np
    brand_m = FIELD_RE["brand"].search(body)
    brand = detect_brand(brand_m.group(1) if brand_m else title)
    score_m = FIELD_RE["score"].search(body)
    author_score = parse_author_score(score_m.group(1) if score_m else "")

    post = Post(
        url=url, title=title, author=author, brand=brand,
        product_name=name.strip(), price=price, author_score=author_score,
        review_text=body.strip(), posted_at=posted,
        is_reply=title.strip().lower().startswith("re:"),
        comments=parse_pushes(soup),
    )
    post.push_count = sum(1 for c in post.comments if c.tag == "推") - \
        sum(1 for c in post.comments if c.tag == "噓")
    return post


def parse_pushes(soup: BeautifulSoup) -> list[Comment]:
    comments = []
    for push in soup.select("div.push"):
        tag_el = push.select_one(".push-tag")
        user_el = push.select_one(".push-userid")
        txt_el = push.select_one(".push-content")
        time_el = push.select_one(".push-ipdatetime")
        if not (tag_el and user_el):
            continue
        tag = tag_el.get_text(strip=True)
        tag = "推" if tag.startswith("推") else "噓" if tag.startswith("噓") else "→"
        text = (txt_el.get_text() if txt_el else "").lstrip("：: ").strip()
        comments.append(Comment(tag=tag, user=user_el.get_text(strip=True), text=text))
    return comments


class _Empty:
    def get_text(self, *a, **k):
        return ""
