"""情感分析(PRD F3 / §8)。

v0 策略:推噓標籤先驗 + 中文詞典微調。
- 推/噓標籤是作者明確表態,最可靠 → 當基準先驗。
- 詞典處理否定、程度副詞、超商食物常見正負詞 → 微調。
- 後端可插拔(預留 snownlp / llm)。
"""
from __future__ import annotations

from .config import SENTIMENT
from .models import Comment

# ── 種子詞典(超商食物評論語境,可持續擴充)──────────────────
# 固定片語先比對(避免否定詞處理失誤,例:不錯=正面)
FIXED_PHRASES = {
    "不錯": 1.0, "不雷": 1.0, "不貴": 0.8, "不油": 0.6, "不會雷": 1.0,
    "不好吃": -1.0, "不推": -1.0, "不優": -0.8, "沒很好吃": -0.6, "不怎麼樣": -0.8,
    "踩雷": -1.0, "地雷": -1.0, "母湯": -0.8, "翻車": -0.9, "雷區": -0.8,
    "回購": 1.0, "必買": 1.0, "大推": 1.0, "推爆": 1.0, "佛心": 0.9,
}

POSITIVE = {
    "好吃": 1.0, "好喝": 1.0, "美味": 1.0, "推": 0.8, "讚": 0.9, "棒": 0.9,
    "喜歡": 0.8, "愛": 0.7, "香": 0.6, "濃郁": 0.7, "多汁": 0.7, "軟嫩": 0.7,
    "划算": 0.8, "劃算": 0.8, "值得": 0.7, "驚艷": 1.0, "驚喜": 0.8, "順口": 0.6,
    "清爽": 0.5, "扎實": 0.5, "神": 0.8, "好評": 0.9, "可": 0.4, "加分": 0.7,
    "出乎意料": 0.6, "意外": 0.4, "好棒": 1.0, "超讚": 1.0, "強": 0.6,
}

NEGATIVE = {
    "難吃": -1.0, "雷": -0.9, "噁": -1.0, "貴": -0.5, "偏貴": -0.6, "死貴": -0.9,
    "坑": -0.8, "騙": -0.8, "普": -0.5, "失望": -0.9, "乾": -0.5, "柴": -0.6,
    "鹹": -0.4, "死鹹": -0.8, "油膩": -0.6, "膩": -0.5, "難喝": -1.0, "後悔": -0.9,
    "扣分": -0.7, "糟": -0.8, "爛": -0.9, "普通": -0.4, "錯愕": -0.5, "硬": -0.4,
}

NEGATORS = ["不", "沒", "別", "毫不", "並不", "不太", "不會"]
INTENSIFIERS = {"超": 1.6, "很": 1.3, "非常": 1.7, "爆": 1.7, "夠": 1.3,
                "真的": 1.3, "有夠": 1.7, "極": 1.7, "太": 1.4, "蠻": 1.2, "好": 1.2}
DIMINISHERS = {"有點": 0.6, "稍微": 0.6, "略": 0.6, "一點": 0.7, "還算": 0.7}


def _tag_score(tag: str) -> float:
    return {"推": 1.0, "噓": -1.0}.get(tag, 0.0)  # → 視為 0


def lexicon_score(text: str) -> float | None:
    """詞典情感分 ∈ [-1, 1];完全無命中回 None。"""
    if not text:
        return None
    text = text.strip()
    total = 0.0
    hits = 0
    remaining = text

    # 1) 固定片語(最長匹配,先處理避免被否定詞誤翻)
    for phrase, val in sorted(FIXED_PHRASES.items(), key=lambda x: -len(x[0])):
        while phrase in remaining:
            total += val
            hits += 1
            remaining = remaining.replace(phrase, "　", 1)  # 佔位避免重複命中

    # 2) 單詞 + 前綴否定/程度
    for lexicon in (POSITIVE, NEGATIVE):
        for word, base in lexicon.items():
            start = 0
            while True:
                idx = remaining.find(word, start)
                if idx == -1:
                    break
                val = base
                window = remaining[max(0, idx - 3):idx]
                # 程度副詞
                for it, mult in INTENSIFIERS.items():
                    if window.endswith(it):
                        val *= mult
                        break
                for dm, mult in DIMINISHERS.items():
                    if window.endswith(dm):
                        val *= mult
                        break
                # 否定 → 翻轉
                if any(neg in window for neg in NEGATORS):
                    val = -val * 0.9
                total += val
                hits += 1
                start = idx + len(word)

    if hits == 0:
        return None
    # 壓縮到 [-1, 1]
    return max(-1.0, min(1.0, total / 2.0))


def analyze_comment(c: Comment) -> float:
    """融合推噓先驗與詞典分,回傳 [-1,1] 並寫回 c.sentiment。"""
    alpha = SENTIMENT["tag_prior_weight"]
    s_tag = _tag_score(c.tag)
    s_lex = lexicon_score(c.text)
    if s_lex is None:
        s = s_tag                      # 無文字訊號 → 靠標籤
    else:
        s = alpha * s_tag + (1 - alpha) * s_lex
    s = max(-1.0, min(1.0, s))
    c.sentiment = s
    return s


def analyze_post_comments(comments: list[Comment]) -> None:
    for c in comments:
        analyze_comment(c)
