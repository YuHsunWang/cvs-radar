"""集中設定:品牌對照表 + 所有可調參數(對應 PRD §14)。

調參只需改這裡;演算法不寫死任何數字。
"""
from __future__ import annotations

# ── 品牌關鍵字對照(PRD 附錄 A)─────────────────────────────
# key = 標準品牌代碼;value = 比對用關鍵字(小寫比對)
BRANDS: dict[str, list[str]] = {
    "7-11": ["7-11", "711", "7-eleven", "7eleven", "小7", "小七", "seven", "統一超", "ibon"],
    "全家": ["全家", "familymart", "family mart", "fami", "全家便利商店"],
    "萊爾富": ["萊爾富", "hi-life", "hilife", "hi life"],
    "OK": ["ok超商", "okmart", "ok mart", "ok便利"],
    "美聯社": ["美聯社"],
}
BRAND_OTHER = "其他"


# ── 爬蟲(PRD F1)─────────────────────────────────────────
CRAWL = {
    "board": "CVS",
    "base_url": "https://www.ptt.cc",
    "max_pages": 5,            # 從最新往回爬幾頁
    "request_delay_sec": 1.0,  # 每次請求間隔(禮貌爬取)
    "timeout_sec": 10,
    "retries": 3,
    "user_agent": "cvs-radar/0.1 (research; contact: you@example.com)",
}


# ── 情感分析(PRD F3 / §8)──────────────────────────────────
SENTIMENT = {
    "backend": "lexicon",      # lexicon / snownlp / llm(v0 只實作 lexicon)
    "tag_prior_weight": 0.6,   # α:推噓標籤先驗的融合比重
}


# ── 評分聚合(PRD F5 / §8)──────────────────────────────────
SCORING = {
    "author_weight": 0.5,      # 作者自評分佔比(留言佔 1 - author_weight)→ 使用者指定 50/50
    "prior_mean": 0.5,         # μ0:貝氏先驗均值
    "prior_strength": 3.0,     # C:貝氏先驗強度(虛擬票數)
    "time_decay_lambda": 0.0,  # λ:時間衰減(每日),0 = 關閉
    "per_user_cap": True,      # 每商品每人折一票
    "exclude_self_push": True, # 作者對自己文章的推文不計入
}


# ── 可疑帳號偵測(PRD F4 / §8)──────────────────────────────
SUSPICION = {
    "min_activity": 5,         # 總留言數低於此值不評可疑分
    "weight_floor": 0.1,       # 信度權重下限(降權但不歸零)
    "feature_weights": {       # 各弱訊號權重(加總後截到 [0,1])
        "one_sided": 0.5,      # 一面倒(挺某品牌、貶競品)
        "single_brand": 0.3,   # 只在單一品牌活動
        "extremity": 0.2,      # 情感長期貼極值
    },
}


# ── 共識分類門檻(PRD F6 / §8)──────────────────────────────
CONSENSUS = {
    "n_eff_min": 3.0,          # 低於此 → 資料不足
    "high_mean": 0.70,         # 好評均值門檻
    "low_mean": 0.40,          # 負評均值門檻
    "low_std": 0.15,           # 一致(低離散)門檻
    "high_std": 0.25,          # 兩極(高離散)門檻
}

# 信心度分級(由 n_eff)
CONFIDENCE_BANDS = [(3.0, "低"), (8.0, "中")]  # < 3 低、3–8 中、> 8 高
